from django.urls import path
from .formulariod100 import FiltrarAPIFormularioD100
from .formulariop100 import FiltrarAPIFormularioP100
from .formulariod8 import FiltrarAPIFormularioD8
from .formulariop8 import FiltrarAPIFormularioP8

urlpatterns = [
    path('api/filtrar/d100/', FiltrarAPIFormularioD100.as_view(), name='filtrar_api_d100'),
    path('api/filtrar/p100/', FiltrarAPIFormularioP100.as_view(), name='filtrar_api_p100'),
    path('api/filtrar/d8/', FiltrarAPIFormularioD8.as_view(), name='filtrar_api_d8'),
    path('api/filtrar/p8/', FiltrarAPIFormularioP8.as_view(), name='filtrar_api_p8'),
]
