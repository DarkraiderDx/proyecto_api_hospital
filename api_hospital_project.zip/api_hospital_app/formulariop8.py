import requests
import pandas as pd
from datetime import datetime, timedelta
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.conf import settings
import json
import redis
import locale


locale.setlocale(locale.LC_TIME, 'es_ES.UTF-8')


class FiltrarAPIFormularioP8(APIView):
    def get(self, request):
        redis_client = redis.StrictRedis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            db=settings.REDIS_DB
        )

        datos = redis_client.get('datos_2024_p8')
        if datos:
            datos = json.loads(datos)
        else:
            datos = self.fetch_data_por_mes(
                'http://apimedical.hospitalpotosi.org.bo/api/v1/dash/p8', 2024
            )
            redis_client.set('datos_2024_p8', json.dumps(datos))
            print("Datos de la API insertados en Redis con caducidad de 24 horas.")

        df = pd.DataFrame(datos)

        df['nombre_completo_medico'] = df['dmonbres'] + \
            ' ' + df['dpaterno'] + ' ' + df['dmaterno']

        df['mes'] = pd.to_datetime(
            df['fecha_solicitud']).dt.strftime('%B').str.capitalize()
        df['año'] = pd.to_datetime(df['fecha_solicitud']).dt.year

        df['año'] = pd.to_numeric(df['año'], errors='coerce')
        df = df.dropna(subset=['año'])
        años_unicos = df['año'].unique().tolist()
        # Determinar año vigente o el especificado por el usuario
        año_vigente = datetime.now().year
        if not request.query_params.getlist('año'):
            df = df[df['año'] == año_vigente]
        else:
            filtro_año = list(map(int, request.query_params.getlist('año')))
            df = df[df['año'].isin(filtro_año)]

        # Actualización de listas únicas según el año filtrado
        medicos_unicos = df['nombre_completo_medico'].dropna(
        ).unique().tolist()
        servicios_unicos = df['servicio'].dropna().unique().tolist()
        meses_unicos = df['mes'].dropna().unique().tolist()
        pacientes_unicos = df['tipo_paciente'].dropna().unique().tolist()
        df['solicitudes'] = df['fecha_anulacion'].apply(
            lambda x: 'Realizado' if pd.isnull(x) else 'Eliminado')

        # Aplicar filtros solo dentro del año vigente o el año solicitado
        filtro_mes = request.query_params.getlist('mes', None)
        filtro_sexo = request.query_params.getlist('sexo', None)
        filtro_servicio = request.query_params.getlist('servicio', None)
        filtro_medico = request.query_params.getlist('medico', None)
        filtro_solicitud = request.query_params.getlist('solicitud', None)
        filtro_tipo_paciente = request.query_params.getlist('paciente', None)
        if filtro_mes:
            df = df[df['mes'].isin(filtro_mes)]
        if filtro_sexo:
            df = df[df['sexo'].isin(filtro_sexo)]
        if filtro_servicio:
            df = df[df['servicio'].isin(filtro_servicio)]
        if filtro_medico:
            df = df[df['nombre_completo_medico'].isin(filtro_medico)]
        if filtro_solicitud:
            df = df[df['solicitudes'].isin(filtro_solicitud)]
        if filtro_tipo_paciente:
            df = df[df['tipo_paciente'].isin(filtro_tipo_paciente)]

        df.fillna(value='', inplace=True)

        prestacion = df[['prestacion', 'mes','servicio']]
        datos_filtrados = prestacion.to_dict(orient='records')

        datos_unicos_id = (
            df.groupby('id')
            .agg({
                'sexo': lambda x: list(set(x.dropna())),
                'servicio': lambda x: list(set(x.dropna())),
                'solicitudes': lambda x: list(set(x.dropna())),
                'mes': lambda x: list(set(x.dropna())),
            })
            .reset_index()
            .to_dict(orient='records')
        )

        return Response({
            "datos_filtrados": datos_filtrados,
            "datos_unicos_id": datos_unicos_id,
            "medicos_unicos": medicos_unicos,
            "servicios_unicos": servicios_unicos,
            "meses_unicos": meses_unicos,
            "años_unicos": años_unicos,
            "pacientes_unicos": pacientes_unicos
        }, status=status.HTTP_200_OK)

    def fetch_data_por_mes(self, api_url, year):
        all_data = []

        for month in range(1, 13):
            start_date = datetime(year, month, 1)
            next_month = start_date.replace(day=28) + timedelta(days=4)
            end_date = next_month - timedelta(days=next_month.day)

            start_str = start_date.strftime('%Y-%m-%d')
            end_str = end_date.strftime('%Y-%m-%d')

            response = requests.get(
                api_url, params={'start': start_str, 'end': end_str})

            if response.status_code == 200:
                data = response.json()
                all_data.extend(data)
                print(f'Datos del {start_str} al {
                      end_str} obtenidos con éxito')
            else:
                print(f'Error al recuperar datos para el rango {
                      start_str} - {end_str}')

        return all_data
