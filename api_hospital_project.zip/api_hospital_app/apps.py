from django.apps import AppConfig


class ApiHospitalAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api_hospital_app'
