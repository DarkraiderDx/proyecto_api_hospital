function toggleSubmenu(submenuId) {
    var submenu = document.getElementById(submenuId);
    if (submenu.style.display === 'block') {
        submenu.style.display = 'none';
    } else {
        submenu.style.display = 'block';
    }
}

function showSection(sectionId) {
    var sections = document.getElementsByClassName('content-section');
    for (var i = 0; i < sections.length; i++) {
        sections[i].style.display = 'none';
    }
    document.getElementById(sectionId).style.display = 'block';
}
document.addEventListener("DOMContentLoaded", function() {
    const innerDiv = document.querySelector('.contenedor_para_grafico_inicial > div');
    if (innerDiv) {
        innerDiv.style.paddingBottom = '0';
        innerDiv.style.height = '600px';
    }

    const iframe = innerDiv.querySelector('iframe');
    if (iframe) {
        iframe.style.width = '100%';
        iframe.style.height = '100%';
        iframe.style.minHeight = '600px';
    }
});


function showSection(id) {
    
    var sections = document.querySelectorAll('.content-section');
    sections.forEach(function(section) {
        section.style.display = 'none';
    });
    
    
    var sectionToShow = document.getElementById(id);
    if (sectionToShow) {
        sectionToShow.style.display = 'block';
    }
}


var hash = window.location.hash.substring(1);  


if (hash) {
    showSection(hash);
}


document.querySelectorAll('button[data-url]').forEach(button => {
    button.addEventListener('click', function() {
            
        window.location.href = this.getAttribute('data-url');
    });
});

