import pandas as pd
import plotly.express as px
from dash import html, dcc
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc
from dash.dash_table import DataTable
from django_plotly_dash import DjangoDash

app = DjangoDash('farmacia_d2', external_stylesheets=[dbc.themes.BOOTSTRAP, dbc.icons.FONT_AWESOME, dbc.icons.BOOTSTRAP])

def generarTabla(dataframe):
    return DataTable(
        data=dataframe.to_dict('records'),
        columns=[{"name": i, "id": i} for i in dataframe.columns],
        style_table={'overflowX': 'auto'},
        style_cell={'textAlign': 'center'},
        style_header={
            'backgroundColor': 'rgb(230, 230, 230)',
            'fontWeight': 'bold'
        }
    )

def crearTablaCantidadMes(dataframe, sexo):
    if sexo != 'TODOS':
        dataframe = dataframe[dataframe['sexo'] == sexo]
    servicios_por_meses = dataframe.groupby(['SERVICIO ', 'mes']).size().reset_index(name='Cantidad_por_mes')
    tabla_pivotada = servicios_por_meses.pivot(index='SERVICIO ', columns='mes', values='Cantidad_por_mes').fillna(0).reset_index()

    meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto']
    tabla_pivotada.columns = ['Servicios'] + meses

    tabla_pivotada['Total'] = tabla_pivotada[meses].sum(axis=1)
    total_row = pd.DataFrame([['Total'] + tabla_pivotada[meses].sum().tolist() + [tabla_pivotada['Total'].sum()]], columns=['Servicios'] + meses + ['Total'])
    
    return pd.concat([tabla_pivotada, total_row], ignore_index=True)



df = pd.read_excel(r"D:\practica_laboral\datos\D8.xlsx", sheet_name='d8final')
df['fecha_solicitud'] = pd.to_datetime(df['fecha_solicitud'])
df['mes'] = df['fecha_solicitud'].dt.month

servicios_sexo = df.groupby(['SERVICIO ', 'sexo']).size().reset_index(name='Cantidad')
 
lista_sexo= ['TODOS'] + df['sexo'].drop_duplicates().tolist()
lista_servicios = ['TODOS'] + df['TIPO DE SERVICIO'].drop_duplicates().tolist()
lista_doctores = ['TODOS'] + df['MEDICO_SOLICITANTE'].drop_duplicates().tolist()

app.layout = dbc.Container([
    dbc.Row([
        dbc.Col(html.H6('Filtro Sexo de Pacientes'), style={'margin-left': '32%'}),
        dbc.Col(html.H6('Filtro Doctores')),
        dbc.Col(html.H6('Filtro Servicios Realizados')),
    ]),

    dbc.Row([
         dbc.Alert([
            html.I(className='fa-solid fa-person', style={'fontSize': '30px'}),  
            html.Span(id='kpi-hombres', style={'fontSize': '20px'})  
        ], color="info", style={'width': '10%', 'margin-left': '10px'}),

        dbc.Alert([
            html.I(className='fa-solid fa-person-dress', style={'fontSize': '30px'}),  
            html.Span(id='kpi-mujeres', style={'fontSize': '20px'})  
        ], color="danger", style={'width': '10%', 'margin-left': '10px'}),

        dbc.Alert([
            html.I(className='bi bi-people-fill', style={'fontSize': '30px'}),  
            html.Span(id='kpi-total', style={'fontSize': '20px'})  
        ], color="success", style={'width': '10%', 'margin-left': '10px'}),
        
        dbc.Col(dcc.Dropdown(
            id='filtro_sexo_drop',
            options=[{'label': i, 'value': i} for i in lista_sexo],
            value=lista_sexo[0],
            searchable=False,
            style={'width': '100%'}
        ), width=2),
        dbc.Col(dcc.Dropdown(
            id='filtro_doctor_drop',
            options=[{'label': i, 'value': i} for i in lista_doctores],
            value=lista_doctores[0],
            searchable=False,
            style={'width': '100%'}
        ), width=3),
        dbc.Col(dcc.Dropdown(
            id='filtro_servicio_drop',
            options=[{'label': i, 'value': i} for i in lista_servicios],
            value=lista_servicios[0],
            searchable=False,
            style={'width': '100%'}
        ), width=3),
    ], className='mb-4'),

    dbc.Row([
        dbc.Col(html.Div(id='output-container', style={'marginTop': '20px', 'fontSize': '20px'}))
    ]),

    html.Hr(),

    dbc.Row([
        dbc.Col(dcc.Graph(id='bar-graph')),
        dbc.Col(dcc.Graph(id='bar-graph2')),
    ]),

    html.Hr(),

    html.H4('Cantidad de Servicios por Mes'),

    dbc.Row([
        dbc.Col(html.Div(id='table-container'))
    ])
], fluid=True)

@app.callback(
    [Output('output-container', 'children'),
     Output('bar-graph', 'figure'),
     Output('bar-graph2', 'figure'),
     Output('table-container', 'children'),
     Output('kpi-hombres', 'children'),
     Output('kpi-mujeres', 'children'),
     Output('kpi-total', 'children')],
    [Input('filtro_sexo_drop', 'value'),
     Input('filtro_doctor_drop', 'value'),
     Input('filtro_servicio_drop', 'value')]
)
def update_output(valor_sexo, valor_doctor, valor_servicio):
    filtrar_df = df.copy()

    # Aplicar filtros
    if valor_sexo != 'TODOS':
        filtrar_df = filtrar_df[filtrar_df['sexo'] == valor_sexo]
    if valor_doctor != 'TODOS':
        filtrar_df = filtrar_df[filtrar_df['MEDICO_SOLICITANTE'] == valor_doctor]
    if valor_servicio != 'TODOS':
        filtrar_df = filtrar_df[filtrar_df['TIPO DE SERVICIO'] == valor_servicio]

    # Calcular totales filtrados
    total_hombres = filtrar_df[filtrar_df['sexo'] == 'MASCULINO'].shape[0]
    total_mujeres = filtrar_df[filtrar_df['sexo'] == 'FEMENINO'].shape[0]
    total_general = filtrar_df.shape[0]

    # Gráfico de barras
    servicios_sexo = filtrar_df.groupby(['SERVICIO ', 'sexo']).size().reset_index(name='Cantidad')

    fig = px.bar(servicios_sexo, x='SERVICIO ', y='Cantidad', color='sexo',
                 labels={'SERVICIO ': 'Servicio', 'Cantidad': 'Número de Personas', 'sexo': 'Género'},
                 title='Número de Personas por Servicio')

    fig.update_layout(
        transition_duration=1000,  
    )

    fig2 = px.line(servicios_sexo, x='SERVICIO ', y='Cantidad', color='sexo',
                 labels={'SERVICIO ': 'Servicio', 'Cantidad': 'Número de Personas', 'sexo': 'Género'},
                 title='Número de Personas por Servicio')
    fig2.update_layout(
        transition_duration=1000,  
    )
    
    tabla_pivot = crearTablaCantidadMes(filtrar_df, valor_sexo)
    tabla = generarTabla(tabla_pivot)

    return (
        f'Número de Personas ({valor_sexo}) por Servicio Farmacia D2',
        fig,
        fig2,
        tabla,
        f'Hombres: {total_hombres}',
        f'Mujeres: {total_mujeres}',
        f'General: {total_general}'
    )
