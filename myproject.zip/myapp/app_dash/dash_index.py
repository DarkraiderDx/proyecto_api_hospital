import dash
from dash import dcc, html
from django_plotly_dash import DjangoDash
import pandas as pd
import plotly.express as px

app = DjangoDash('mi_dashboard')

# Datos
data = {
    'Categoría': ['A', 'B', 'C', 'D'],
    'Valor': [10, 20, 30, 40]
}
df = pd.DataFrame(data)


fig = px.bar(
    df, 
    x='Categoría', 
    y='Valor', 
    title='Grafica de Ejemplo',
    color_discrete_sequence=['#dd3030']  
)

# Layout de la aplicación Dash
app.layout = html.Div(
    [
        html.Div(
            [
                dcc.Graph(
                    id='bar-chart-1',
                    figure=fig,
                    style={
                        'width': '30%',
                        'height': '300px',
                        'margin-right': '10px'
                    }
                ),
                dcc.Graph(
                    id='bar-chart-2',
                    figure=fig,
                    style={
                        'width': '30%',
                        'height': '300px',
                        'margin-right': '10px'
                    }
                ),
                dcc.Graph(
                    id='bar-chart-3',
                    figure=fig,
                    style={
                        'width': '30%',
                        'height': '300px'
                    }
                )
            ],
            style={
                'display': 'flex',
                'margin-top': '120px',
                'flex-direction': 'row',
                'justify-content': 'space-between'
            }
        )
    ],
    id='mi_div',
)
