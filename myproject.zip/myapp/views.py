from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib import messages

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            next_url = request.POST.get('next') or 'index'
            return redirect(next_url)  
        else:
            messages.error(request, 'Usuario o contraseña incorrectos')
    next_url = request.GET.get('next', '')
    return render(request, 'login_page.html', {'next': next_url})

@login_required
def user_logout(request):
    auth_logout(request)
    return redirect('login')  

@login_required
def index(request):
    return render(request, 'index.html')

@login_required
def detalles(request):
    return render(request, 'details_page.html')
